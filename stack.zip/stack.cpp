#include "stack.h"
#include <iostream>
using namespace std;

void createStack_103032400094(stack &S) {
    S.top = 0;
}

bool isEmpty_103032400094(stack S) {
    return S.top == 0;
}

bool isFull_103032400094(stack S) {
    return S.top == MAXSTACK;
}

void push_103032400094(stack &S, infotype x) {
    if (!isFull_103032400094(S)) {
        S.info[S.top] = x;
        S.top++;
    } else {
        cout << "stack sudah penuh!" << endl;
    }
}

infotype pop_103032400094(stack &S) {
    S.top--;
    return S.info[S.top];
}

int sumStack_103032400094(stack S) {
    int total = 0;
    while (!isEmpty_103032400094(S)) {
        total += pop_103032400094(S);
    }
    return total;
}
